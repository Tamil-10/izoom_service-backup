package com.izoom.izoomservice.product.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.izoom.izoomservice.product.dao.ProductInstDAO;
import com.izoom.izoomservice.product.pojo.Product_Inst;

@RestController
@RequestMapping(value = "/api/productinst")
public class ProductInstService {
	private static Logger LOGGER = LoggerFactory.getLogger(ProductInstService.class);
	@Autowired
	ProductInstDAO productInstDAO;


	@RequestMapping(method = RequestMethod.POST, value = "addProduct")
	public Product_Inst addProduct(@RequestBody Product_Inst product_Inst) throws Exception {
		LOGGER.info("addProduct enter");
		Product_Inst result = null;
		try {
			product_Inst.setCreated_date(new Date());
			result = productInstDAO.addProduct(product_Inst);
		} catch (Exception e) {
			e.printStackTrace();
		}
		LOGGER.info("addProduct exit");
		return result;
	}

	@RequestMapping(method = RequestMethod.GET, value = "getCartCount/{userId}")
	public int getCartCount(@PathVariable(value = "userId") String userId) throws Exception {
		LOGGER.info("getCartCount enter");
		int result = 0;
		try {
			result = productInstDAO.getCartCount(userId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		LOGGER.info("getCartCount exit");
		return result;
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "getOrderSummary/{userId}")
	public List<Map<String, Object>> getOrderSummary(@PathVariable(value = "userId") String userId) throws Exception {
		LOGGER.info("getOrderSummary enter");
		List<Map<String, Object>> result = null;
		try {
			result = productInstDAO.getOrderSummary(userId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		LOGGER.info("getOrderSummary exit");
		return result;
	}

}
