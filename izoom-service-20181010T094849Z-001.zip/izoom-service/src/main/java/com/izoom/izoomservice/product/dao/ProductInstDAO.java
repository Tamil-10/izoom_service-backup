package com.izoom.izoomservice.product.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.izoom.izoomservice.poll.pojo.PollVO;
import com.izoom.izoomservice.product.pojo.Product;
import com.izoom.izoomservice.product.pojo.Product_Inst;
import com.izoom.izoomservice.product.pojo.SearchCriteria;
import com.izoom.izoomservice.product.repository.ProductInstRespository;

@Repository
public class ProductInstDAO {

	private static Logger LOGGER = LoggerFactory.getLogger(ProductInstDAO.class);

	@Autowired
	ProductInstRespository productInstRespository;

	@Autowired
	JdbcTemplate jdbcTemplate;

	public Product_Inst addProduct(Product_Inst product_Inst) {
		LOGGER.info("addProduct enter::" + product_Inst);
		System.out.println("getProduct_id::" + product_Inst.getProduct_id());
		String prod_inst_sql = "select * from product_inst where product_id=? and status=?";
		List<Product_Inst> _prod_Inst_list = ((List<Product_Inst>) jdbcTemplate.query(prod_inst_sql, (rs, rowNum) -> {
			Product_Inst tempProduct_Inst = new Product_Inst();
			tempProduct_Inst.setId(rs.getLong("ID"));
			tempProduct_Inst.setQuantity(rs.getLong("QUANTITY"));
			return tempProduct_Inst;
		}, new Object[] { product_Inst.getProduct_id(), "Draft" }));

		if (_prod_Inst_list != null && !_prod_Inst_list.isEmpty()) {
			product_Inst.setQuantity(_prod_Inst_list.get(0).getQuantity() + product_Inst.getQuantity());
			product_Inst.setId(_prod_Inst_list.get(0).getId());
			LOGGER.info("_prod_Inst_prod_Inst_prod_Inst:::" + _prod_Inst_list.get(0));
		}
		productInstRespository.save(product_Inst);
		LOGGER.info("addProduct exit::" + product_Inst);

		return product_Inst;
	}

	public int getCartCount(String userId) {
		LOGGER.info("getCartCount enter::" + userId);
		String prod_inst_sql = "select sum(quantity)QTY from product_inst where user_id=? and status=?";
		int count = 0;
		try {
			count = jdbcTemplate.queryForObject(prod_inst_sql, new Object[] { userId, "Draft" }, Integer.class);
		} catch (DataAccessException e) {
			LOGGER.info("Data Not Found");
		}
		LOGGER.info("getCartCount exit::" + count);
		return count;
	}

	public List<Map<String, Object>> getOrderSummary(String userId) {
		LOGGER.info("getOrderSummary enter::" + userId);
		String prod_inst_sql = "select pi.product_id \"product_id\", pi.quantity \"quantity\", p.name \"name\",p.description \"description\", p.price \"price\",p.content \"content\",p.content_type \"content_type\" from product_inst pi, product p where pi.user_id=? and pi.status=? and pi.product_id= p.id";
		List<Map<String, Object>> result = null;
		try {
			result = jdbcTemplate.queryForList(prod_inst_sql, new Object[] { userId, "Draft" });
		} catch (DataAccessException e) {
			LOGGER.info("Data Not Found");
			e.printStackTrace();
		}
		LOGGER.info("getOrderSummary exit::" + result);
		return result;
	}

}
