package com.izoom.izoomservice.product.dao;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.izoom.izoomservice.poll.pojo.PollVO;
import com.izoom.izoomservice.product.pojo.Product;
import com.izoom.izoomservice.product.pojo.SearchCriteria;
import com.izoom.izoomservice.product.repository.ProductRespository;

@Repository
public class ProductDAO {

	private static Logger LOGGER = LoggerFactory.getLogger(ProductDAO.class);

	@Autowired
	ProductRespository productRespository;

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Value("${productpagelimit}")
	String limit;

	public String productconfiguration(Product product) {
		LOGGER.info("productconfiguration enter");
		System.out.println("name::" + product.getName());
		productRespository.save(product);
		LOGGER.info("productconfiguration exit");
		return "success";
	}

	public List<Product> retrieveProductList(SearchCriteria searchCriteria) {
		LOGGER.info("retrieveProductList enter");
		List<Product> productList = null;
		try {
			int lmt = searchCriteria.getLimit() < 1 ? 5 : searchCriteria.getLimit();
			String sortBy = searchCriteria.getSortBy();
			int start = searchCriteria.getStart();
			Sort sort = new Sort(new Sort.Order(Direction.ASC, sortBy != null ? sortBy : "id"));
			Pageable pageable = new PageRequest(start, lmt, sort);
			productList = new ArrayList<>();
			productRespository.findByStatus("Active",pageable).forEach(productList::add);
			productList.forEach(product -> System.out.println(product.getName()));
		} catch (Exception e) {
			e.printStackTrace();
		}
		LOGGER.info("retrieveProductList exit");
		return productList;
	}

	public Product delete(Product product) throws Exception {
		LOGGER.info("delete enter");
		try {
			LOGGER.info("poll_id::::" + product.getId());
			jdbcTemplate.update("update PRODUCT set status = 'Deleted' where id=?", new Object[] { product.getId() });
		} catch (Exception e) {
			e.printStackTrace();
		}
		LOGGER.info("poll id:::" + product.getId());
		LOGGER.info("delete exit");
		return product;
	}

}
